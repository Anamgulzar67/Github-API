import React from "react";
import "./App.css";
import DatawithAPI from "./components/DatawithAPI";

function App() {
  return (
    <>
      <div>
        <DatawithAPI />
      </div>
    </>
  );
}

export default App;
